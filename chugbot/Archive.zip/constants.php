<?php
    define("DEBUG", FALSE);

    define("MAX_SIZE_NUM", 10000);
    define("MIN_SIZE_NUM", -1);
    define("DEFAULT_PREF_COUNT", 6);

// Important: use 127.0.0.1:8889 as the host when running PHPUnit tests.  For regular use,
// use localhost.
//    define("MYSQL_HOST", "127.0.0.1:8889");
    define("MYSQL_HOST", getenv("MYSQL_HOST"));
    define("MYSQL_USER", getenv("MYSQL_USER"));
    define("MYSQL_PASSWD", getenv("MYSQL_PASSWD"));             // This should be changed in production use.
    define("MYSQL_DB", getenv("MYSQL_DB"));
    define("MYSQL_PATH", "/Applications/MAMP/Library/bin"); // This should be changed in production use.

    define("ADMIN_EMAIL_USERNAME", "chug@campramahne.org");
    define("ADMIN_EMAIL_PASSWORD", "chug@campramahne.org"); // This should be changed in production use
?>
